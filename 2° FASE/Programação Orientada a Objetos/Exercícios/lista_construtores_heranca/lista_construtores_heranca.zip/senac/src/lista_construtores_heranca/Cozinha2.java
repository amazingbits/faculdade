package lista_construtores_heranca;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Cozinha2 {

	public static void main(String[] args) {
		
		int option = 1;
		int itens = 0;
		Scanner teclado = new Scanner(System.in);
		//vari�vel apenas para formatar o resultado decimal
		DecimalFormat df = new DecimalFormat("#.##");
		
		double consumoDia = 0;
		double consumoMes = 0;
		double custoDia = 0;
		double custoMes = 0;
		
		Geladeira geladeira = new Geladeira();
		Fogao fogao = new Fogao();
		FornoEletrico forno = new FornoEletrico();
		LavaLouca lavaLouca = new LavaLouca();
		Microondas microondas = new Microondas();
		
		while(option != 0) {
			System.out.println("Escolha um item: \n\n1- Geladeira\n2- Fog�o\n3- Forno El�trico\n4- Lava Lou�as\n5- Microondas\n\n0 - Sair");
			option = teclado.nextInt();
			Utils.clrscr();
			
			//controle para que o usu�rio escolha somente o que eu quero
			if(option < 0 || option > 5) {
				Utils.clrscr();
				System.out.println("Op��o inv�lida!");
				System.exit(0);
			}
			
			if(option == 0) {
				break;
			}
			
			if(option == 1) {
				Utils.formulario(geladeira, teclado);
				consumoDia += geladeira.calcularKwDia(10);
				consumoMes += geladeira.calcularKwMes();
				custoDia += geladeira.calcularValor(consumoDia);
				custoMes += geladeira.calcularValor(consumoMes);
				itens++;
			}else if(option == 2) {
				Utils.formulario(fogao, teclado);
				consumoDia += fogao.calcularKwDia(10);
				consumoMes += fogao.calcularKwMes();
				custoDia += fogao.calcularValor(consumoDia);
				custoMes += fogao.calcularValor(consumoMes);
				itens++;
			}else if(option == 3) {
				Utils.formulario(forno, teclado);
				consumoDia += forno.calcularKwDia(10);
				consumoMes += forno.calcularKwMes();
				custoDia += forno.calcularValor(consumoDia);
				custoMes += forno.calcularValor(consumoMes);
				itens++;
			}else if(option == 4) {
				Utils.formulario(lavaLouca, teclado);
				consumoDia += lavaLouca.calcularKwDia(10);
				consumoMes += lavaLouca.calcularKwMes();
				custoDia += lavaLouca.calcularValor(consumoDia);
				custoMes += lavaLouca.calcularValor(consumoMes);
				itens++;
			}else {
				Utils.formulario(microondas, teclado);
				consumoDia += microondas.calcularKwDia(10);
				consumoMes += microondas.calcularKwMes();
				custoDia += microondas.calcularValor(consumoDia);
				custoMes += microondas.calcularValor(consumoMes);
				itens++;
			}
			
		}
		
		//sa�da
		if(itens <= 0) {
			Utils.clrscr();
			System.out.println("Voc� n�o cadastrou nenhum item.");
		}else {
			Utils.clrscr();
			System.out.println("CONSUMO DA COZINHA (10 DIAS): " + df.format(consumoDia) + " KW/DIA - R$ " + df.format(custoDia));
			System.out.println("CONSUMO DA COZINHA (M�S): " + df.format(consumoMes) + " KW/M�S - R$ " + df.format(custoMes));
		}

	}

}
