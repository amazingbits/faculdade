package lista_construtores_heranca;

public class FornoEletrico extends Eletrodomesticos {
	
	FornoEletrico(){
		
	}
	
	FornoEletrico(String modelo, String fabricante, double capacidade, double potencia, double horas){
		this.modelo = modelo;
		this.fabricante = fabricante;
		this.capacidade = capacidade;
		this.potencia = potencia;
		this.horasUsadas = horas;
	}

	@Override
	protected double calcularKw() {
		/*comportamento espec�fico para o forno el�trico*/
		double kwh = (this.potencia * this.horasUsadas) / 1000;
		return somarDesperdicio(kwh);
		
	}

	@Override
	protected double calcularKwDia(int diasUsados) {
		return this.calcularKw() * diasUsados;
	}

	@Override
	protected double calcularKwMes() {
		return this.calcularKw() * 30;
	}
	
	@Override
	protected double calcularValor(double kwh) {
		return this.tarifa * kwh;
	}
	
	private double somarDesperdicio(double kwh) {
		return kwh += (kwh * 0.25);
	}

}
