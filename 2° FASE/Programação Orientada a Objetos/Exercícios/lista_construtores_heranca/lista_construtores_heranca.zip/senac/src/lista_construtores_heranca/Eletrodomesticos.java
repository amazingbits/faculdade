package lista_construtores_heranca;

public abstract class Eletrodomesticos {
	
	protected String modelo;
	protected String fabricante;
	protected double capacidade;
	
	protected int diasUsados;
	protected double horasUsadas;
	protected double potencia;
	
	//tarifa de luz da CELESC por KWh
	protected double tarifa = 0.469780;
	
	protected String getModelo() {
		return this.modelo;
	}
	
	protected void setModelo(String modelo) {
		this.modelo = modelo;
	}
	
	protected String getFabricante() {
		return this.fabricante;
	}
	
	protected void setFabricante(String fabricante) {
		this.fabricante = fabricante;
	}
	
	protected double getCapacidade() {
		return this.capacidade;
	}
	
	protected void setCapacidade(double capacidade) {
		this.capacidade = capacidade;
	}
	
	protected int getDiasUsados() {
		return diasUsados;
	}

	protected void setDiasUsados(int diasUsados) {
		this.diasUsados = diasUsados;
	}

	protected double getHorasUsadas() {
		return horasUsadas;
	}

	protected void setHorasUsadas(double horasUsadas) {
		this.horasUsadas = horasUsadas;
	}

	protected double getPotencia() {
		return potencia;
	}

	protected void setPotencia(double potencia) {
		this.potencia = potencia;
	}

	protected abstract double calcularKw();
	
	protected abstract double calcularKwDia(int diasUsados);
	
	protected abstract double calcularKwMes();
	
	protected abstract double calcularValor(double kwh);
	
}
