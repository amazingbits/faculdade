package lista_construtores_heranca;

import java.util.Scanner;

public class Utils {
	//gambiarra pra "limpar" console. s� pra ficar mais organizado
	public static void clrscr(){
		for(int i = 0; i < 50; i++) {
			System.out.println("");
		}
	}
	
	public static void formulario(Eletrodomesticos item, Scanner teclado) {
		teclado.nextLine();
		System.out.println("Digite o modelo do item: ");
		item.setModelo(teclado.nextLine());
		Utils.clrscr();
		System.out.println("Digite o fabricante do " + item.getModelo() + "? ");
		item.setFabricante(teclado.nextLine());
		Utils.clrscr();
		System.out.println("Digite a capacidade (litros ou quilos) do item " + item.getModelo() + " do fabricante " + item.getFabricante() + " (SOMENTE N�MERO): ");
		item.setCapacidade(teclado.nextDouble());
		Utils.clrscr();
		System.out.println("Digite a pot�ncia em WATTS do item: ");
		item.setPotencia(teclado.nextDouble());
		Utils.clrscr();
		System.out.println("Qual a m�dia de horas por dia o item fica ligado? ");
		item.setHorasUsadas(teclado.nextDouble());
		Utils.clrscr();
	}
	
}
