package lista_construtores_heranca;

public class Geladeira extends Eletrodomesticos {
	
	Geladeira(){
		
	}
	
	Geladeira(String modelo, String fabricante, double capacidade, double potencia, double horas){
		this.modelo = modelo;
		this.fabricante = fabricante;
		this.capacidade = capacidade;
		this.potencia = potencia;
		this.horasUsadas = horas;
	}

	@Override
	protected double calcularKw() {
		return (this.potencia * this.horasUsadas) / 1000;
	}

	@Override
	protected double calcularKwDia(int diasUsados) {
		return this.calcularKw() * diasUsados;
	}

	@Override
	protected double calcularKwMes() {
		return this.calcularKw() * 30;
	}
	
	@Override
	protected double calcularValor(double kwh) {
		return this.tarifa * kwh;
	}

}
