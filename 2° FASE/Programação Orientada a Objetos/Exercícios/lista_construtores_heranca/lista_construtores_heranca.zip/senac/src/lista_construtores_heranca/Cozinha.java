package lista_construtores_heranca;

import java.text.DecimalFormat;

public class Cozinha {
	
	public static void main(String[] args) {
		
		//vari�vel apenas para formatar o resultado decimal
		DecimalFormat df = new DecimalFormat("#.##");
		
		double consumoDia = 0;
		double consumoMes = 0;
		double custoDia = 0;
		double custoMes = 0;
		
		Geladeira g = new Geladeira(
										"Frost Free Especial", //modelo
										"Samsung",             //fabricante
										500,                   //capacidade em litros
										250,                   //pot�ncia em Watts
										8                      //horas ligada por dia
									);
		
		consumoDia += g.calcularKwDia(10);
		consumoMes += g.calcularKwMes();
		custoDia += g.calcularValor(consumoDia);
		custoMes += g.calcularValor(consumoMes);
		
		Fogao f = new Fogao(
								"Inox Turbo Ac. Autom�tico", //modelo
								"Brastemp",                  //fabricante
								5,                           //qtde de bocas
								1500,                        //pot�ncia em Watts
								1                            //horas ligado por dia
							);
		
		consumoDia += f.calcularKwDia(10);
		consumoMes += f.calcularKwMes();
		custoDia += f.calcularValor(consumoDia);
		custoMes += f.calcularValor(consumoMes);
		
		LavaLouca l = new LavaLouca(
									"Ultra High", //modelo
									"Electrolux", //fabricante
									15.3,         //capacidade
									1450,         //potencia
									1             //horas
									);
		consumoDia += l.calcularKwDia(10);
		consumoMes += l.calcularKwMes();
		custoDia += l.calcularValor(consumoDia);
		custoMes += l.calcularValor(consumoMes);
		
		Microondas m = new Microondas(
										"Inox",   //modelo
										"Consul", //fabricante
										20,       //capacidade
										2000,     //potencia
										0.3       //horas
									 );
		consumoDia += m.calcularKwDia(10);
		consumoMes += m.calcularKwMes();
		custoDia += m.calcularValor(consumoDia);
		custoMes += m.calcularValor(consumoMes);
		
		FornoEletrico fEletrico = new FornoEletrico(
													"Power Inox", //modelo
													"Consul",     //fabricante
													30,           //capacidade
													2500,         //potencia
													0.4           //horas
												   );
		consumoDia += fEletrico.calcularKwDia(10);
		consumoMes += fEletrico.calcularKwMes();
		custoDia += fEletrico.calcularValor(consumoDia);
		custoMes += fEletrico.calcularValor(consumoMes);
		
		System.out.println("CONSUMO DA COZINHA (10 DIAS): " + df.format(consumoDia) + " KW/DIA - R$ " + df.format(custoDia));
		System.out.println("CONSUMO DA COZINHA (M�S): " + df.format(consumoMes) + " KW/M�S - R$ " + df.format(custoMes));
		
	}

}
